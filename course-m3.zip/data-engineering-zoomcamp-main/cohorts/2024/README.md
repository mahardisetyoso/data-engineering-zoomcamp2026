## Data Engineering Zoomcamp 2024 Cohort

* [Pre-launch Q&A stream](https://www.youtube.com/watch?v=91b8u9GmqB4)
* [Launch stream with course overview](https://www.youtube.com/live/AtRhA-NfS24?si=5JzA_E8BmJjiLi8l)
* [Deadline calendar](https://docs.google.com/spreadsheets/d/e/2PACX-1vQACMLuutV5rvXg5qICuJGL-yZqIV0FBD84CxPdC5eZHf8TfzB-CJT_3Mo7U7oGVTXmSihPgQxuuoku/pubhtml)
* [FAQ](https://datatalks.club/faq/data-engineering-zoomcamp.html)
* Course Playlist: Only 2024 Live videos & homeworks (TODO)
* [Public Leaderboard of Top-100 Participants](leaderboard.md)


[**Module 1: Introduction & Prerequisites**](01-docker-terraform/)

* [Homework](01-docker-terraform/homework.md)


[**Module 2: Workflow Orchestration**](02-workflow-orchestration)

* [Homework](02-workflow-orchestration/homework.md)
* Office hours

[**Workshop 1: Data Ingestion**](workshops/dlt.md)

* Workshop with dlt
* [Homework](workshops/dlt.md)


[**Module 3: Data Warehouse**](03-data-warehouse)

* [Homework](03-data-warehouse/homework.md)


[**Module 4: Analytics Engineering**](04-analytics-engineering/)

* [Homework](04-analytics-engineering/homework.md)


[**Module 5: Batch processing**](05-batch/)

* [Homework](05-batch/homework.md)


[**Module 6: Stream Processing**](06-streaming)

* [Homework](06-streaming/homework.md)


[**Project**](project.md)

More information [here](project.md)
