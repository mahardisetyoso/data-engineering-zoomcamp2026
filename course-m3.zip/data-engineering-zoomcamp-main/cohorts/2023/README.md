## Data Engineering Zoomcamp 2023 Cohort

* [Launch stream with course overview](https://www.youtube.com/watch?v=-zpVha7bw5A)
* [FAQ](https://datatalks.club/faq/data-engineering-zoomcamp.html)
* [Public Leaderboard](leaderboard.md) and [Private Leaderboard](https://docs.google.com/spreadsheets/d/e/2PACX-1vTbL00GcdQp0bJt9wf1ROltMq7s3qyxl-NYF7Pvk79Jfxgwfn9dNWmPD_yJHTDq_Wzvps8EIr6cOKWm/pubhtml)
* [Course Playlist: Only 2023 Live videos & homeworks](https://www.youtube.com/playlist?list=PL3MmuxUbc_hJjEePXIdE-LVUx_1ZZjYGW)

[**Week 1: Introduction & Prerequisites**](week_1_docker_sql/)

* [Homework SQL](week_1_docker_sql/homework.md) and [solution](https://www.youtube.com/watch?v=KIh_9tZiroA)
* [Homework Terraform](week_1_terraform/homework.md)
* [Office hours](https://www.youtube.com/watch?v=RVTryVvSyw4&list=PL3MmuxUbc_hJjEePXIdE-LVUx_1ZZjYGW)

[**Week 2: Workflow Orchestration**](week_2_workflow_orchestration)

* [Homework](week_2_workflow_orchestration/homework.md)
* [Office hours part 1](https://www.youtube.com/watch?v=a_nmLHb8hzw&list=PL3MmuxUbc_hJjEePXIdE-LVUx_1ZZjYGW) and [part 2](https://www.youtube.com/watch?v=PK8yyMY54Vk&list=PL3MmuxUbc_hJjEePXIdE-LVUx_1ZZjYGW&index=7) 

[**Week 3: Data Warehouse**](week_3_data_warehouse)

* [Homework](week_3_data_warehouse/homework.md)
* [Office hours](https://www.youtube.com/watch?v=QXfmtJp3bXE&list=PL3MmuxUbc_hJjEePXIdE-LVUx_1ZZjYGW)

[**Week 4: Analytics Engineering**](week_4_analytics_engineering/)

* [Homework](week_4_analytics_engineering/homework.md)
* [PipeRider + dbt Workshop](workshops/piperider.md)
* [Office hours](https://www.youtube.com/watch?v=ODYg_r72qaE&list=PL3MmuxUbc_hJjEePXIdE-LVUx_1ZZjYGW)

[**Week 5: Batch processing**](week_5_batch_processing/)

* [Homework](week_5_batch_processing/homework.md)
* [Office hours](https://www.youtube.com/watch?v=5_69yL2PPYI&list=PL3MmuxUbc_hJjEePXIdE-LVUx_1ZZjYGW)

[**Week 6: Stream Processing**](week_6_stream_processing)

* [Homework](week_6_stream_processing/homework.md)


[**Week 7, 8 & 9: Project**](project.md)

More information [here](project.md)
