## Thank you!

Thanks for signing up for the course.

The process of adding you to the mailing list is not automated yet, 
but you will hear from us closer to the course start. 

To make sure you don't miss any announcements

- Register in [DataTalks.Club's Slack](https://datatalks.club/slack.html) and
  join the [`#course-data-engineering`](https://app.slack.com/client/T01ATQK62F8/C01FABYF2RG) channel
- Join the [course Telegram channel with announcements](https://t.me/dezoomcamp)
- Subscribe to [DataTalks.Club's YouTube channel](https://www.youtube.com/c/DataTalksClub) and check 
  [the course playlist](https://www.youtube.com/playlist?list=PL3MmuxUbc_hJed7dXYoJw8DoCuVHhGEQb)

See you in January!
