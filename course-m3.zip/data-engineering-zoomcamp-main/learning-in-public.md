# Learning in public

Most people learn in private: they consume content but don't tell
anyone about it. There's nothing wrong with it.

But we want to encourage you to document your progress and
share it publicly on social media.

It helps you get noticed and will lead to:

* Expanding your network: meeting new people and making new friends
* Being invited to meetups, conferences and podcasts
* Landing a job or getting clients
* Many other good things

Here's a more comprehensive reading on why you want to do it: https://github.com/readme/guides/publishing-your-work


## Learning in Public for Zoomcamps

When you submit your homework or project, you can also submit
learning in public posts:

<img src="https://github.com/DataTalksClub/mlops-zoomcamp/raw/main/images/learning-in-public-links.png" />

You can watch this video to see how your learning in public posts may look like:

<a href="https://www.loom.com/share/710e3297487b409d94df0e8da1c984ce" target="_blank">
    <img src="https://github.com/DataTalksClub/mlops-zoomcamp/raw/main/images/learning-in-public.png" height="240" />
</a>

## Daily Documentation

- **Post Daily Diaries**: Document what you learn each day, including the challenges faced and the methods used to overcome them.
- **Create Quick Videos**: Make short videos showcasing your work and upload them to GitHub.

Send a PR if you want to suggest improvements for this document
